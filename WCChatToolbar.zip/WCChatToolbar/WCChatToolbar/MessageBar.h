//
//  MessageBar.h
//  WCChatToolbar
//
//  Created by Sérgio Vieira on 4/3/13 - sergiosvieira@gmail.com
//  http://www.linkedin.com/profile/view?id=111238929&trk=tab_pro
//  Copyright (c) 2013 Bravo Inovação. All rights reserved.
//
//  Description: This is a complete message toolbar component that can be used in chat applications

#import <UIKit/UIKit.h>

@interface MessageBar : UIControl
{
@private
    UIToolbar *toolbar;
    BOOL isUp;
    UIControl *control;
}

#pragma mark - Class Methods
+ (CGFloat)height;

#pragma mark - Lazy Properties
@property (nonatomic, strong) UIBarButtonItem *bbiActions;
@property (nonatomic, strong) UITextField *tfText;
@property (nonatomic, strong) UIBarButtonItem *bbiSend;

#pragma mark - Public Methods
- (id)initWithFrame:(CGRect)frame withResizableControl:(UIControl *)resizeableControl;
- (void)enableKeyboardNotifications;

@end
