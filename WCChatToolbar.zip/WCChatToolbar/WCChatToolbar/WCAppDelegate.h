//
//  WCAppDelegate.h
//  WCChatToolbar
//
//  Created by Sérgio Vieira on 4/3/13 - sergiosvieira@gmail.com
//  http://www.linkedin.com/profile/view?id=111238929&trk=tab_pro
//  Copyright (c) 2013 Bravo Inovação. All rights reserved.
//
//  Description: This is a complete message toolbar component that can be used in chat applications

#import <UIKit/UIKit.h>

@interface WCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
