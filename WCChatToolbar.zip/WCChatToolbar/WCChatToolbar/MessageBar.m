//
//  MessageBar.m
//  WCChatToolbar
//
//  Created by Sérgio Vieira on 4/3/13 - sergiosvieira@gmail.com
//  http://www.linkedin.com/profile/view?id=111238929&trk=tab_pro
//  Copyright (c) 2013 Bravo Inovação. All rights reserved.
//
//  Description: This is a complete message toolbar component that can be used in chat applications

#import "MessageBar.h"

#define kTOOLBAR_HEIGHT 44.f
#define kPORTRAIT_KEYBOARD_HEIGHT 216.f
#define kLANDSCAPE_KEYBOARD_HEIGHT 162.f

@implementation MessageBar

- (UIBarButtonItem *)bbiActions
{
    if (!_bbiActions)
    {
        _bbiActions = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:
            @selector(selActions:)];
        
        /** customization **/
        _bbiActions.style = UIBarButtonItemStyleBordered;
    }
    
    return _bbiActions;
}

- (UITextField *)tfText
{
    if (!_tfText)
    {
        CGRect frame = CGRectMake
        (
            0.f,//self.bbiActions.width,
            0.f,
            200.f,
            31.f
        );
        
        _tfText = [[UITextField alloc] initWithFrame:frame];
        
        /** customization **/
        _tfText.borderStyle = UITextBorderStyleRoundedRect;
        _tfText.font = [UIFont systemFontOfSize:15];
        _tfText.placeholder = NSLocalizedString(@"Type a message", nil);
        _tfText.autocorrectionType = UITextAutocorrectionTypeNo;
        _tfText.keyboardType = UIKeyboardTypeDefault;
        _tfText.returnKeyType = UIReturnKeyDone;
        _tfText.clearButtonMode = UITextFieldViewModeWhileEditing;
        _tfText.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    }
    
    return _tfText;
}

- (UIBarButtonItem *)bbiSend
{
    if (!_bbiSend)
    {
        _bbiSend = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Send", nil) style:UIBarButtonItemStyleBordered
            target:self action:@selector(selSend:)];
        
        /** customization **/
    }
    
    return _bbiSend;
}

#pragma mark - Class Methods
+ (CGFloat)height
{
    return kTOOLBAR_HEIGHT;
}

#pragma mark - Init
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self)
    {
        [self begin];
        [self enableKeyboardNotifications];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame withResizableControl:(UIControl *)resizeableControl
{
    self = [super initWithFrame:frame];
    
    if (self)
    {
        [self begin];
        [self enableKeyboardNotifications];
        control = resizeableControl;
    }
    
    return self;
}

#pragma mark - Public Methods
- (void)enableKeyboardNotifications
{
    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
    
    [defaultCenter addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [defaultCenter addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - Private Methods
- (void)setViewMovedUp:(BOOL)movedUp notification:(NSNotification *)aNotification
{

    CGRect controlFrame;
    CGFloat keyboardHeight = [self getCurrentKeyboarHeight];
    CGRect frame = self.frame;
    
    if (control)
    {
        controlFrame = control.frame;
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.27]; // if you want to slide up the view
    
    if (movedUp)
    {
        if (control)
        {
            controlFrame.size.height = control.frame.size.height - keyboardHeight;
        }
        
        frame.origin.y = frame.origin.y - keyboardHeight;
    }
    else
    {
        if (control)
        {
            controlFrame.size.height = control.frame.size.height + keyboardHeight;
        }
        
        frame.origin.y = frame.origin.y + keyboardHeight;
    }
    
    if (control)
    {
        control.frame = controlFrame;
    }
    
    self.frame = frame;
    [UIView commitAnimations];
}


#pragma mark - Selectors
- (void)selActions:(id)sender
{
    if (!isUp)
    {
        [self setViewMovedUp:YES notification:nil];
        isUp = YES;
    }
    else
    {
        isUp = NO;
        [self endEditing:YES];
        isUp = YES;
    }
    
}

- (void)selSend:(id)sender
{
}

- (void)keyboardWillShow:(NSNotification *)aNotification
{
    if (!isUp)
    {
        [self setViewMovedUp:YES notification:aNotification];
        isUp = YES;
    }
}

- (void)keyboardWillHide:(NSNotification *)aNotification
{
    if (isUp)
    {
        [self setViewMovedUp:NO notification:aNotification];
        isUp = NO;
    }
}

#pragma mark - Private Methods
- (CGFloat)getCurrentKeyboarHeight
{
    CGFloat result = kPORTRAIT_KEYBOARD_HEIGHT;
    UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    
    if (!UIInterfaceOrientationIsPortrait(interfaceOrientation))
    {
        result = kLANDSCAPE_KEYBOARD_HEIGHT;
    }

    return result;
}

- (void)begin
{
    CGRect screenFrame = [[UIScreen mainScreen] bounds];
    CGRect statusbarFrame = [[UIApplication sharedApplication] statusBarFrame];
    CGRect frame;
    
    /** toolbar **/
    frame = CGRectMake
    (
        0.f,
        0.f,
        self.frame.size.width,
        kTOOLBAR_HEIGHT
    );
    
    toolbar = [[UIToolbar alloc] initWithFrame:frame];
    
    UIBarButtonItem *bbiText = [[UIBarButtonItem alloc] initWithCustomView:self.tfText];
    [self.tfText setBackgroundColor:[UIColor whiteColor]];
    
    // adding items
    NSArray *items =
    @[
        self.bbiActions,
        bbiText,
        self.bbiSend
    ];
    
    toolbar.items = items;
    [self addSubview:toolbar];
    
    /** customization **/
    // initializations
    control = nil;
    isUp = NO;
    
    // Layout
    //[self setBackgroundColor:[UIColor lightGrayColor]];
    
    // Size
    frame = self.frame;
    frame.size.height = kTOOLBAR_HEIGHT + [self getCurrentKeyboarHeight];
    
    // Positioning
    frame = self.frame;
    frame.origin.y = screenFrame.size.height - kTOOLBAR_HEIGHT - statusbarFrame.size.height;
    self.frame = frame;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
